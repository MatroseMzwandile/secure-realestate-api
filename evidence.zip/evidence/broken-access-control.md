## Broken Access Control - Editing/Deleting Others' Listings

1. I first check the current listings :scrrenshot 3
1. then i login as alice and bob using their correct passwords: screenshot3
2. then i exploit 'bob's listing as alice. I modify it and rename it to 'Hacked by me(ALice)' and change its properties.: scrrenshot 3
3. thenn i check bobs listing to see the properties, and indeeed they have been changed: scrrenshot3
4. then i log in as bob : scrrenshot 4
4. then i delete alices listing as bob. That should not be allowed: scrrenshot 4
5. then check the remaining listings. : screenshot 4

Explanation: update()/delete() only check that the listing id exists,
never that request.realtorId matches listings.realtor_id. Any logged-in
realtor can modify or delete any listing.